import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-reports',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent {
  reportsList = [
    { name: 'AWB Sales Report', route: '/reports/awb-sales' },
    { name: 'AWB Print Report', route: '/reports/awb-print' }
  ];
}
