import { Component } from '@angular/core';

@Component({
  selector: 'app-delivery-state',
  templateUrl: './delivery-state.component.html',
  styleUrls: ['./delivery-state.component.css']
})
export class DeliveryStateComponent { }
