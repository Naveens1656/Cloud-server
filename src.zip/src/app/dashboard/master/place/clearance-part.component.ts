import { Component } from '@angular/core';

@Component({
  selector: 'app-clearance-part',
  templateUrl: './clearance-part.component.html',
  styleUrls: ['./clearance-part.component.css']
})
export class ClearancePartComponent { }
